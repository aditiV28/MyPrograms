<?php
$you=$_POST['username'];
//echo $you;
include_once 'dbconfig.php';
if(!$user->is_loggedin())
{
 $user->redirect('index.php');
}
$user_id = $_SESSION['user_session'];
$stmt = $DB_con->prepare("SELECT * FROM users WHERE user_id=:user_id");
$stmt->execute(array(":user_id"=>$user_id));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
$result=array();
$result=$user->lets_chat($userRow['user_name'],$you);
echo json_encode($result);
//echo $result;
//print_r($result);
?>
