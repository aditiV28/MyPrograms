$('.arrow').height($('.direct-chat-text').innerHeight());
    $("textfield").hide();
     var loggedinuser;


    function viewmodel(){
      var self = this;
      self.currentchat = ko.observable();
     self.obj1 = ko.observableArray();
     self.chat = ko.observableArray();
     self.message=ko.observable();
     self.visibility = ko.observable(false);

     self.sendmessage=function(){
      var d = new Date();
      var n = d.getTime();
       var obj=loggedinuser+','+self.message()+','+n;
       var currchat={"currentchat":self.currentchat(),"string":obj};
       console.log(currchat);
       console.log(obj);
       $.ajax({
              url: "sendchat.php",
              type: "POST",
              data:currchat,
              success: function(msg){
                 console.log(msg);
              }
            });
       self.message("");
       var yourchat={"username":self.currentchat()};
       $.ajax({
              url: "mychat.php",
              type: "POST",
              data:yourchat,
              success: function(msg){
                 self.chat(JSON.parse(msg));
                 console.log(JSON.parse(msg));
              }
            });
     }
      $.ajax({
              url: "get_name.php",
              type: "GET",
              success: function(msg){
                 loggedinuser=msg;
                 console.log(msg);
                 console.log(typeof(loggedinuser));
              }
            });

      self.showchatwindow=function(data){
        self.visibility(true);
        self.currentchat(data.user_name);
        var yourchat={"username":data.user_name};
        $.ajax({
              url: "mychat.php",
              type: "POST",
              data:yourchat,
              success: function(msg){
                 self.chat(JSON.parse(msg));
                 console.log(JSON.parse(msg));
              }
            });
        all_messages();
      }

      setInterval(all_online,10000);
      function all_online(){

        $.ajax({
              url: "all_except_me.php",
              type: "GET",
              success: function(msg){
                 self.obj1(JSON.parse(msg));
                 //console.log(JSON.parse(msg));
              }
            });
    }
     function all_messages(){
          var yourchat={"username":self.currentchat()};
       $.ajax({
              url: "mychat.php",
              type: "POST",
              data:yourchat,
              success: function(msg){
                 self.chat(JSON.parse(msg));
                 console.log(JSON.parse(msg));
              }
            });
       setInterval(all_messages,10000);
     };

    }
    ko.applyBindings(new viewmodel());
  