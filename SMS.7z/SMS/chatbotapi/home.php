<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" />
<link rel="stylesheet" href="css/style.css" type="text/css"  />
<link rel="stylesheet" href="css/front_end.css" type="text/css"  />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/knockout.js"></script>
<title>welcome</title>
</head>

<body>

<div class="header">
 <div class="left">
     <label><a href="http://www.codingcage.com/">Chatbot</a></label>
    </div>
    <div class="right">
     <label><a href="logout.php"><i class="glyphicon glyphicon-log-out"></i> logout</a></label>

     <label class="deactive"><a href="deactivate.php"><i class="glyphicon glyphicon-trash"></i>Delete Account</a></label>
    </div>
</div>

<div class="container">
    <div class="row">
      <div class="userlist col-md-4">
        <ul data-bind="foreach:obj1">
            
            <!--<div class="btn btn-primary custom_userlist" data-bind=" text:user_name ,click:$parent.showchatwindow">
                <div class="status_div" data-bind="style:{backgroundColor:status=='0'?'red':'green'}"></div>
            </div>-->
            <div class="btn btn-primary status_button"><div class="status_div" data-bind="style:{backgroundColor:status=='0'?'#ff3713':'#DBFF12'}"></div></div>
            
            <button class="btn btn-primary custom_list" data-bind=" text:user_name ,click:$parent.showchatwindow,style:{color:status=='0'?'#ff3713':'#66D926'}"></button>
            <br>
        </ul>
      </div>

      <div class="panel panel-primary col-md-8" data-bind="visible:visibility">
        <div class="panel-heading">
            <span class="glyphicon glyphicon-comment"></span> Chat
        </div>
        <div class="panel-body">
            <ul class="chat" data-bind="foreach:chat">
                <li class="left clearfix" data-bind="if:(name==loggedinuser)">
                    <span class="chat-img pull-left">
                        <img src="images/u.png" alt="User Avatar" class="img-circle" />
                    </span>
                    <b class="left-caret pull-left"></b>
                    <div class="chat-body clearfix">
                        <div class="direct-chat-text-u u">
                            <div class="chat_message" data-bind="text:message"></div>
                        </div>     
                    </div>
                </li>

                <li class="right clearfix" data-bind="ifnot:(name==loggedinuser)">
                    <span class="chat-img pull-right">
                        <img src="images/me.png" alt="User Avatar" class="img-circle" />
                    </span>
                    <b class="right-caret pull-right"></b>
                    <div class="chat-body clearfix">
                        <div class="direct-chat-text-me me">
                            <div class="chat_message" data-bind="text:message"></div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="panel-footer">
            <div class="input-group">
                <input id="btn-input" type="text" class="form-control input-sm" placeholder="Type your message here..." data-bind="value:message" />
                <span class="input-group-btn">
                    <button class="btn btn-warning btn-sm" id="btn-chat" data-bind="click:sendmessage">Send</button>
                </span>
            </div>
        </div>
    </div>
  </div>
</div>
    
<script src="js/myscript.js"></script>
    
</body>
</html>
