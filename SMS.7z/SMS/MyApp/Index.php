<?php
require_once 'connect.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        $uname = $_POST['user_name'];
        $umail = $_POST['email'];
        $upass = $_POST['password'];

        if($user->login($uname,$umail,$upass))
        {
           // $user->redirect('home.php');
             $logged="Logged in";
             echo json_encode($logged);
        }
        else
        {
            $error = "Wrong Details !";
            echo json_encode($error);
        }
    }
   /* elseif($user->is_loggedin()!="")
    {
        //$user->redirect('home.php');
        $notlogged="Not Logged in";
        echo json_encode($notlogged);
    }*/
?>