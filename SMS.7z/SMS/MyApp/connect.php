<?php
session_start();
 $hostname = "127.0.0.1";
 $username = "root";
 $password = "";
 $dbname = "login";
 
    try{
        $conn = new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password);
        if(!$conn){
            echo 'Error in connection';
        }
        else{
            echo 'Connected succesfully';
        }
    }

catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

include_once 'class.user.php';
$user = new USER($conn);

?>