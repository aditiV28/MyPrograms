<?php
class USER
{
    private $db;

    function __construct($conn)
    {
      $this->db = $conn;
    }

    public function login($uname,$umail,$upass)
    {
       try
       {
          $stmt = $this->db->prepare("SELECT * FROM users WHERE user_name=:uname OR email=:umail LIMIT 1");
          $stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
              echo json_encode("user present");
             //if(password_verify($upass,password_hash($userRow['password'],PASSWORD_DEFAULT )))
            
              if(md5($upass)==$userRow['password'])
             {
                $_SESSION['user_session'] = $userRow['user_id'];
                /*$stmt = $this->db->prepare("UPDATE users SET status=1 WHERE user_name=:uname");
                $stmt->bindparam(":uname", $uname);
                $stmt->execute();*/
                //echo json_encode(password_hash($userRow['password'],PASSWORD_DEFAULT ));
                return true;
             }
             else
             {
                return false;
             }
          }
          else {
            return false;
          }
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }

   public function is_loggedin()
   {
      if(isset($_SESSION['user_session']))
      {
         return true;
      }
   }

   public function redirect($url)
   {
       header("Location: $url");
   }

   public function logout($username)
   {
     try {
         /* $stmt1 = "UPDATE users SET status=0 WHERE user_name ='$username'";
          $this->db->exec($stmt1);*/
          session_destroy();
          unset($_SESSION['user_session']);
          return true;

     } catch (PDOException $e) {
       echo $e->getMessage();
       return false;
     }

   }
    
   public function forgot_password($email)
   {
           $stmt = $this->db->prepare("SELECT * FROM users WHERE  email=:umail LIMIT 1");
           $stmt->bindparam(':umail',$email);
           $stmt->execute();
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
                $to = $email;
                 $subject = "Reset Password";

                 $message = $userRow['password'];
                 $message .= "<h1>This is your password.</h1>";

                 $header = "From:divya.rajwani123@gmail.com \r\n";
                 //$header .= "Cc:afgh@somedomain.com \r\n";
                 $header .= "MIME-Version: 1.0\r\n";
                 $header .= "Content-type: text/html\r\n";

                 $retval = mail ($to,$subject,$message,$header);

                 if( $retval == true ) {
                    echo "Message sent successfully...";
                     return true;
                 }else {
                    echo "Message could not be sent...";
                     return false;
                 }
          }
       else
       {
           echo json_encode("invalid email");
       }
   }
  


 

  

}
?>
